<div align="center">
  <img src="assets/banner.svg" alt="Aditya Seth — Creative Web Developer" width="100%" />

  <h1>Hi, I'm Aditya Seth 👋</h1>
  <h3>Creative Web Developer · Frontend Developer · Future Full-Stack Developer</h3>

  <a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.demolab.com?font=JetBrains+Mono&weight=600&size=18&pause=1100&color=22D3EE&center=true&vCenter=true&width=720&lines=Web+Developer;Frontend+Developer;Creative+Developer;Building+Modern+Web+Experiences;Always+Learning+and+Exploring+Technology" alt="Animated headline: Web Developer, Frontend Developer, Creative Developer, Building Modern Web Experiences, Always Learning and Exploring Technology" />
  </a>

  <br />
  <a href="https://github.com/sethaditya220-afk">
    <img src="https://komarev.com/ghpvc/?username=sethaditya220-afk&label=PROFILE+VIEWS&color=0891b2&style=for-the-badge" alt="Profile views" />
  </a>
  <a href="mailto:sethaditya220@gmail.com">
    <img src="https://img.shields.io/badge/Email-Say%20hello-a78bfa?style=for-the-badge&logo=gmail&logoColor=white" alt="Email Aditya" />
  </a>
</div>

## About me

I'm **Aditya Seth**, a web developer passionate about building modern, responsive, interactive, and visually engaging web experiences. I enjoy combining thoughtful interface design with practical frontend development, and I'm continuing to grow toward full-stack development.

- 🎯 **Current focus:** creating polished, responsive web experiences.
- 🌱 **Learning:** full-stack web development and the technologies in the suggested stack below.
- 💡 **Interested in:** frontend development, creative interfaces, and useful web products.
- 🚀 **Goal:** keep learning, build projects that solve real problems, and grow as a developer.

## Suggested web developer technology stack

These are **suggestions**, not claims about tools I use. Remove any technology that doesn't match my actual experience.

### Frontend development

HTML5 · CSS3 · JavaScript · TypeScript · React.js · Next.js · Tailwind CSS · Bootstrap · Responsive Web Design

<p>
  <img src="https://skillicons.dev/icons?i=html,css,js,ts,react,nextjs,tailwind,bootstrap&theme=dark" alt="Suggested frontend technologies: HTML, CSS, JavaScript, TypeScript, React, Next.js, Tailwind CSS, and Bootstrap" />
</p>

### Backend development

Node.js · Express.js · REST APIs

<p>
  <img src="https://skillicons.dev/icons?i=nodejs,express&theme=dark" alt="Suggested backend technologies: Node.js and Express.js" />
</p>

### Database technologies

MongoDB · MySQL · Firebase

<p>
  <img src="https://skillicons.dev/icons?i=mongodb,mysql,firebase&theme=dark" alt="Suggested databases: MongoDB, MySQL, and Firebase" />
</p>

### Programming languages

JavaScript · TypeScript · Python

<p>
  <img src="https://skillicons.dev/icons?i=js,ts,python&theme=dark" alt="Suggested programming languages: JavaScript, TypeScript, and Python" />
</p>

### Development tools

Git · GitHub · VS Code · npm · Postman · Chrome DevTools · Figma

<p>
  <img src="https://skillicons.dev/icons?i=git,github,vscode,npm,postman,figma&theme=dark" alt="Suggested tools: Git, GitHub, VS Code, npm, Postman, and Figma" />
</p>

### Deployment and hosting

Vercel · Netlify · GitHub Pages

<p>
  <img src="https://skillicons.dev/icons?i=vercel,netlify&theme=dark" alt="Suggested hosting platforms: Vercel and Netlify" />
</p>

## Connect

<div>
  <a href="https://github.com/sethaditya220-afk">
    <img src="https://img.shields.io/badge/GitHub-Follow-181717?style=for-the-badge&logo=github&logoColor=white" alt="Aditya Seth on GitHub" />
  </a>
  <a href="mailto:sethaditya220@gmail.com">
    <img src="https://img.shields.io/badge/Email-Contact-0891b2?style=for-the-badge&logo=gmail&logoColor=white" alt="Email Aditya Seth" />
  </a>
  <img src="https://img.shields.io/badge/Portfolio-To%20be%20added%20later-7c3aed?style=for-the-badge" alt="Portfolio to be added later" />
  <img src="https://img.shields.io/badge/LinkedIn-To%20be%20added%20later-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn to be added later" />
</div>

## GitHub statistics

These cards load live data from GitHub-connected services; no contribution counts or language rankings are fabricated. Third-party services can occasionally be unavailable or rate-limited.

<div align="center">
  <img height="175" src="https://github-readme-stats.vercel.app/api?username=sethaditya220-afk&show_icons=true&hide_border=true&rank_icon=github&theme=tokyonight" alt="Live GitHub statistics for sethaditya220-afk" />
  <img height="175" src="https://github-readme-stats.vercel.app/api/top-langs/?username=sethaditya220-afk&layout=compact&hide_border=true&theme=tokyonight" alt="Most-used programming languages for sethaditya220-afk" />
</div>

<div align="center">
  <img height="175" src="https://streak-stats.demolab.com?user=sethaditya220-afk&theme=tokyonight&hide_border=true" alt="Live GitHub contribution streak for sethaditya220-afk" />
</div>

### GitHub trophies

<div align="center">
  <img src="https://github-profile-trophy.vercel.app/?username=sethaditya220-afk&theme=tokyonight&no-frame=true&no-bg=true&margin-w=8&row=1" alt="Live GitHub trophies for sethaditya220-afk" />
</div>

### Contribution activity

<div align="center">
  <img src="https://github-readme-activity-graph.vercel.app/graph?username=sethaditya220-afk&bg_color=1a1b27&color=c0caf5&line=7aa2f7&point=bb9af7&area=true&hide_border=true" alt="Live GitHub contribution activity graph for sethaditya220-afk" width="100%" />
</div>

### 3D contribution calendar

The workflow generates real contribution visualizations from GitHub activity. Until its first successful run, the checked-in SVG is only a setup notice—not contribution data.

<div align="center">
  <img src="profile-3d-contrib/profile-night-rainbow.svg" alt="3D GitHub contribution calendar for sethaditya220-afk; run the profile workflow to generate it" width="100%" />
</div>

<div align="center">
  <img src="profile-3d-contrib/profile-green.svg" alt="Green 3D contribution calendar for sethaditya220-afk" width="49%" />
  <img src="profile-3d-contrib/profile-green-animate.svg" alt="Animated green 3D contribution calendar for sethaditya220-afk" width="49%" />
  <img src="profile-3d-contrib/profile-night.svg" alt="Dark 3D contribution calendar for sethaditya220-afk" width="49%" />
  <img src="profile-3d-contrib/profile-season.svg" alt="Seasonal 3D contribution calendar for sethaditya220-afk" width="49%" />
</div>

These are setup notices until generation succeeds. The action also creates other compatible themes in `profile-3d-contrib/`.

### Contribution snake

Generated daily from the public contribution calendar and published to the `output` branch.

<div align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/sethaditya220-afk/sethaditya220-afk/output/github-snake-dark.svg" />
    <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/sethaditya220-afk/sethaditya220-afk/output/github-snake.svg" />
    <img alt="Animated snake traversing Aditya Seth's GitHub contribution grid" src="https://raw.githubusercontent.com/sethaditya220-afk/sethaditya220-afk/output/github-snake.svg" width="100%" />
  </picture>
</div>

## Featured projects

No projects have been specified for featuring yet. Visit [my repositories](https://github.com/sethaditya220-afk?tab=repositories) to see the projects I choose to share; this section can be updated with real project descriptions when ready.

## Developer goals

- Build useful, modern, responsive web experiences.
- Strengthen frontend skills and keep exploring full-stack development.
- Share real projects and learn through building.

## Thanks for visiting

If you're interested in web development or want to connect, [send me an email](mailto:sethaditya220@gmail.com). My portfolio and LinkedIn links will be added when available.

<div align="center">
  <img src="assets/developer-animation.svg" alt="Animated code editor representing creative web development" width="560" />
  <br /><br />
  <img src="assets/footer.svg" alt="Thanks for stopping by — let's keep building" width="100%" />
</div>

---

<details>
  <summary><strong>Setup, deployment, and customization guide</strong></summary>

### 1. Create the profile repository

Create a **public** repository named exactly `sethaditya220-afk` under the GitHub account `sethaditya220-afk`. GitHub displays the repository's README on the matching profile. Add these project files to its default branch:

```text
.
├── .github/
│   └── workflows/
│       ├── profile-3d.yml
│       ├── snake.yml
│       └── update-profile.yml
├── assets/
│   ├── banner.svg
│   ├── developer-animation.svg
│   └── footer.svg
├── profile-3d-contrib/
├── .gitignore
└── README.md
```

### 2. Personalize the profile

The profile already uses the provided name, username, and email. The skills are suggestions: remove technologies you don't use. The portfolio and LinkedIn are intentionally marked as unavailable until their real URLs are provided. Add only projects and accomplishments that reflect your actual work.

### 3. Enable GitHub Actions

In the repository, open **Settings → Actions → General → Workflow permissions**, select **Read and write permissions**, and save. This lets the workflows use the repository-scoped `GITHUB_TOKEN` to commit generated artwork and publish the snake branch. No personal access token or manually configured secret is needed. Keep the repository public for the profile assets to be visible.

### 4. Run the workflows

Open the **Actions** tab and enable workflows if prompted.

1. Select **Generate 3D contribution profile** and click **Run workflow**. The workflow commits generated SVGs to `profile-3d-contrib/` only if files changed.
2. Select **Generate contribution snake** and click **Run workflow**. It creates or updates the `output` branch with light and dark SVGs.
3. Optionally select **Update profile assets** to validate required files and trigger both generators.
4. Confirm the generated files and branch in the repository, then view the profile README.

### 5. Updates and troubleshooting

The 3D profile and snake workflows run daily on a UTC schedule and can also be started manually. GitHub may delay schedules during high load or disable them for inactive repositories.

- **Workflow is missing:** verify the workflow files are committed under `.github/workflows/` on the default branch and Actions are enabled.
- **Push is denied:** enable read/write workflow permissions. The workflows declare only `contents: write`.
- **3D image still shows a setup notice:** check the latest workflow run and ensure its generated `profile-3d-contrib/` files were committed.
- **Snake image is unavailable:** confirm the workflow succeeded, the `output` branch contains `github-snake.svg` and `github-snake-dark.svg`, and the repository name is still `sethaditya220-afk`.
- **Stats, icons, or typing image are unavailable:** the corresponding external image service may be rate-limited or temporarily down. Retry later or remove that image.
- **No commit was made:** generated files were unchanged; this is expected.

### File and folder guide

- `.github/workflows/profile-3d.yml` generates 3D contribution themes daily or on demand and commits only changed artwork.
- `.github/workflows/snake.yml` generates light and dark contribution snakes and publishes them to the `output` branch.
- `.github/workflows/update-profile.yml` validates the required local assets and offers a manual way to run both generators.
- `assets/banner.svg` is the welcome banner; `assets/developer-animation.svg` is the animated code illustration; `assets/footer.svg` is the closing graphic.
- `profile-3d-contrib/` holds generated 3D contribution SVGs. Its checked-in SVG is a setup notice until generation succeeds.
- `README.md` is the profile content and setup guide.
- `.gitignore` excludes local editor files and temporary snake output while keeping profile artwork tracked.

</details>
